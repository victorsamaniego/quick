from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, current_app, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta, timezone
import os
import secrets
from models import db, User, OTPCode, Product, Category, Order, OrderItem
from forms import (
    RegistrationForm, LoginForm, OTPVerificationForm, 
    PasswordResetRequestForm, PasswordResetForm,
    ProductForm, OrderForm, AdminUserForm, CategoryForm
)
from flask_mail import Message

# Blueprints
main_bp = Blueprint('main', __name__)
admin_bp = Blueprint('admin', __name__, url_prefix='/admin')
delivery_bp = Blueprint('delivery', __name__, url_prefix='/delivery')


# ============ UTILIDADES ============

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']


def send_otp_email(user_email, code, purpose):
    """Envía email con código OTP"""
    subject = {
        'register': '🔐 Confirma tu registro en QuickGo',  # 👈 CAMBIADO
        'reset_password': '🔄 Restablece tu contraseña - QuickGo' # 👈 CAMBIADO
    }.get(purpose, 'Código de verificación - QuickGo')
    
    body = f"""
    Hola,
    
    Tu código de verificación es: {code}
    
    Este código expira en {current_app.config['OTP_EXPIRY_MINUTES']} minutos.
    
    Si no solicitaste este código, ignora este mensaje.
    
    Saludos,
    Equipo QuickGo  # 👈 CAMBIADO
    """
    
    try:
        msg = Message(subject, recipients=[user_email], body=body)
        current_app.mail.send(msg)
        return True
    except Exception as e:
        current_app.logger.error(f"Error sending email: {e}")
        print(f"\n🔐 OTP CODE FOR {user_email}: {code}\n")
        return True


def get_featured_products(limit=8):
    """Obtiene productos destacados SIN usar campo is_featured"""
    return Product.query.filter_by(is_active=True).filter(Product.stock > 0)\
        .order_by(Product.created_at.desc()).limit(limit).all()


def get_recent_orders(user_id, limit=3):
    """Obtiene órdenes recientes de un usuario"""
    return Order.query.filter_by(user_id=user_id)\
        .order_by(Order.created_at.desc()).limit(limit).all()


# ============ ROUTES PRINCIPALES (CLIENTE) ============

@main_bp.route('/')
def index():
    # 🔴 Si es delivery, redirigir al panel de delivery
    if current_user.is_authenticated and current_user.is_delivery:
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si es admin, mostrar dashboard con estadísticas de ganancias
    if current_user.is_authenticated and current_user.is_admin:
        # Estadísticas de usuarios
        total_users = User.query.count()
        users_list = User.query.order_by(User.created_at.desc()).all()
        
        # Estadísticas de productos
        all_products = Product.query.filter_by(is_active=True).all()
        total_products = len(all_products)
        total_stock = sum(p.stock for p in all_products)
        
        # Cálculos de ganancias
        total_valor_inventario = sum(p.valor_inventario for p in all_products)
        total_ganancia_potencial = sum(p.ganancia_potencial for p in all_products)
        
        # Margen promedio
        if total_valor_inventario > 0:
            margen_promedio = (total_ganancia_potencial / total_valor_inventario) * 100
        else:
            margen_promedio = 0
        
        # Productos con bajo stock
        low_stock_products = [p for p in all_products if p.is_low_stock]
        
        # Top 5 productos más rentables
        top_rentables = sorted(all_products, key=lambda p: p.ganancia_potencial, reverse=True)[:5]
        
        return render_template('admin/home_stats.html',
            total_users=total_users,
            users_list=users_list,
            total_products=total_products,
            total_stock=total_stock,
            total_valor_inventario=total_valor_inventario,
            total_ganancia_potencial=total_ganancia_potencial,
            margen_promedio=margen_promedio,
            low_stock_products=low_stock_products,
            top_rentables=top_rentables
        )
    
    # 👤 Si es cliente, mostrar productos normales
    products = get_featured_products(limit=12)
    categories = Category.query.all()
    return render_template('products.html', products=products, categories=categories)


@main_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(
            email=form.email.data,
            phone=form.phone.data
        )
        user.set_password(form.password.data)
        
        otp = OTPCode(
            user=user,
            code=OTPCode.generate_code(),
            purpose='register'
        )
        db.session.add(user)
        db.session.add(otp)
        db.session.commit()
        
        if send_otp_email(user.email, otp.code, 'register'):
            flash('✅ Hemos enviado un código de verificación a tu email.', 'success')
            return redirect(url_for('main.verify_otp', user_id=user.id, purpose='register'))
        else:
            flash('⚠️ Error al enviar el email. Intenta nuevamente.', 'warning')
            db.session.delete(user)
            db.session.commit()
    
    return render_template('register.html', form=form)


@main_bp.route('/verify-otp/<int:user_id>/<purpose>', methods=['GET', 'POST'])
def verify_otp(user_id, purpose):
    form = OTPVerificationForm()
    user = User.query.get_or_404(user_id)
    
    if form.validate_on_submit():
        otp = OTPCode.query.filter_by(
            user_id=user_id, 
            code=form.code.data, 
            purpose=purpose, 
            used=False
        ).first()
        
        if otp and not otp.is_expired():
            otp.used = True
            
            if purpose == 'register':
                user.is_active = True
                login_user(user)
                db.session.commit()
                flash('🎉 ¡Registro exitoso! Bienvenido a QuickGo.', 'success') # 👈 CAMBIADO
                return redirect(url_for('main.dashboard'))
            elif purpose == 'reset_password':
                session['reset_user_id'] = user_id
                flash('✅ Código verificado. Ahora establece tu nueva contraseña.', 'success')
                return redirect(url_for('main.reset_password_new'))
            db.session.commit()
        else:
            flash('❌ Código inválido o expirado. Solicita uno nuevo.', 'danger')
    
    return render_template('verify_otp.html', form=form, email=user.email)


@main_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        
        if user and user.check_password(form.password.data):
            if not user.is_active:
                flash('⚠️ Tu cuenta no está activada. Verifica tu email.', 'warning')
                return redirect(url_for('main.register'))
            
            login_user(user)
            flash('👋 ¡Bienvenido de nuevo a QuickGo!', 'success') # 👈 CAMBIADO
            next_page = request.args.get('next')
            return redirect(next_page or url_for('main.dashboard'))
        else:
            flash('❌ Email o contraseña incorrectos.', 'danger')
    
    return render_template('login.html', form=form)


@main_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('👋 Sesión cerrada. ¡Hasta pronto en QuickGo!', 'info') # 👈 CAMBIADO
    return redirect(url_for('main.index'))


@main_bp.route('/dashboard')
@login_required
def dashboard():
    """
    ✅ Dashboard del CLIENTE - Si es ADMIN o DELIVERY, redirige a su panel
    """
    # 🔴 Si es delivery, redirigir INMEDIATAMENTE al panel de delivery
    if current_user.is_delivery:
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si es administrador, redirigir al panel de administración
    if current_user.is_admin:
        return redirect(url_for('admin.dashboard'))
    
    # 👤 Si es cliente, mostrar su dashboard normal
    pending_order = current_user.get_pending_order()
    recent_orders = get_recent_orders(current_user.id, limit=10)
    featured_products = get_featured_products(limit=8)
    user_name = current_user.email.split('@')[0].title()
    
    return render_template('dashboard.html',
        user_name=user_name,
        pending_order=pending_order,
        recent_orders=recent_orders,
        featured_products=featured_products
    )


@main_bp.route('/products')
def products():
    # 🔴 Si es admin, redirigir al panel de gestión de productos
    if current_user.is_authenticated and current_user.is_admin:
        flash('ℹ️ Como administrador, usá el panel de gestión.', 'info')
        return redirect(url_for('admin.manage_products'))
    
    # 🔴 Si es delivery, redirigir al panel de delivery
    if current_user.is_authenticated and current_user.is_delivery:
        flash('ℹ️ Como delivery, usá tu panel de gestión.', 'info')
        return redirect(url_for('delivery.dashboard'))
    
    category_id = request.args.get('category', type=int)
    search = request.args.get('search', type=str)
    
    query = Product.query.filter_by(is_active=True).filter(Product.stock > 0)
    
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    if search:
        query = query.filter(Product.name.ilike(f'%{search}%'))
    
    products = query.order_by(Product.created_at.desc()).all()
    categories = Category.query.all()
    
    return render_template('products.html', products=products, categories=categories, 
                          current_category=category_id, search_term=search)


@main_bp.route('/product/<int:product_id>')
def product_detail(product_id):
    # 🔴 Si es admin, redirigir
    if current_user.is_authenticated and current_user.is_admin:
        return redirect(url_for('admin.manage_products'))
    
    # 🔴 Si es delivery, redirigir
    if current_user.is_authenticated and current_user.is_delivery:
        return redirect(url_for('delivery.dashboard'))
    
    product = Product.query.get_or_404(product_id)
    if not product.is_available:
        flash('⚠️ Este producto no está disponible.', 'warning')
        return redirect(url_for('main.products'))
    return render_template('product_detail.html', product=product)


@main_bp.route('/cart/add/<int:product_id>', methods=['POST'])
@login_required
def add_to_cart(product_id):
    # Admin y Delivery no pueden comprar
    if current_user.is_admin or current_user.is_delivery:
        flash('⚠️ No puedes realizar compras.', 'warning')
        return redirect(url_for('main.dashboard'))
    
    if current_user.get_pending_order():
        flash('⚠️ Ya tienes un pedido pendiente. Completa o cancela ese pedido primero.', 'warning')
        return redirect(url_for('main.dashboard'))
    
    product = Product.query.get_or_404(product_id)
    if not product.is_available:
        flash('❌ Producto no disponible.', 'danger')
        return redirect(url_for('main.products'))
    
    cart = session.get('cart', {})
    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    session['cart'] = cart
    
    flash(f'✅ {product.name} agregado al carrito.', 'success')
    return redirect(request.referrer or url_for('main.products'))


@main_bp.route('/cart')
@login_required
def cart():
    # Admin y Delivery no pueden ver carrito
    if current_user.is_admin or current_user.is_delivery:
        return redirect(url_for('main.dashboard'))
    
    if current_user.get_pending_order():
        flash('⚠️ Ya tienes un pedido pendiente.', 'warning')
        return redirect(url_for('main.dashboard'))
    
    cart = session.get('cart', {})
    cart_items = []
    total = 0
    
    for product_id, quantity in cart.items():
        product = Product.query.get(int(product_id))
        if product and product.is_available:
            subtotal = product.price * quantity
            cart_items.append({
                'product': product,
                'quantity': quantity,
                'subtotal': subtotal
            })
            total += subtotal
    
    return render_template('cart.html', cart_items=cart_items, total=total)


@main_bp.route('/cart/update/<int:product_id>', methods=['POST'])
@login_required
def update_cart(product_id):
    if current_user.is_admin or current_user.is_delivery:
        return redirect(url_for('main.dashboard'))
    
    action = request.form.get('action')
    cart = session.get('cart', {})
    
    if action == 'increase':
        cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    elif action == 'decrease':
        if cart.get(str(product_id), 0) > 1:
            cart[str(product_id)] -= 1
        else:
            cart.pop(str(product_id), None)
    elif action == 'remove':
        cart.pop(str(product_id), None)
    
    session['cart'] = cart
    return redirect(url_for('main.cart'))


# ✅ FUNCION create_order CORREGIDA CON GEOLOCALIZACIÓN

@main_bp.route('/order/create', methods=['GET', 'POST'])
@login_required
def create_order():
    # Admin y Delivery no pueden comprar
    if current_user.is_admin or current_user.is_delivery:
        flash('⚠️ No puedes realizar compras.', 'warning')
        return redirect(url_for('main.dashboard'))
    
    if current_user.get_pending_order():
        flash('⚠️ Ya tienes un pedido pendiente.', 'warning')
        return redirect(url_for('main.dashboard'))
    
    cart = session.get('cart', {})
    if not cart:
        flash('⚠️ Tu carrito está vacío.', 'warning')
        return redirect(url_for('main.products'))
    
    form = OrderForm()
    if form.validate_on_submit():
        total = 0
        order_items_temp = []
        
        # ✅ PASO 1: Calcular total ANTES de crear la orden
        for product_id, quantity in cart.items():
            product = Product.query.get(int(product_id))
            if product and product.is_available and product.stock >= quantity:
                subtotal = product.price * quantity
                total += subtotal
                order_items_temp.append({
                    'product': product,
                    'quantity': quantity,
                    'price': product.price
                })
        
        # ✅ PASO 2: Verificar que total sea válido
        if total <= 0:
            flash('❌ Error en el cálculo del total', 'danger')
            return redirect(url_for('main.cart'))
        
        # ✅ PASO 3: Crear orden CON el total ya calculado
        order = Order(
            user_id=current_user.id,
            total_amount=total,
            shipping_address=form.shipping_address.data,
            shipping_phone=form.shipping_phone.data,
            shipping_reference=form.shipping_reference.data or '',
            status='pending'
        )
        
        # ✅ Guardar ubicación del cliente si está disponible
        user_location = session.get('user_location')
        if user_location:
            order.client_latitude = user_location['latitude']
            order.client_longitude = user_location['longitude']
        
        # ✅ Calcular costo de envío
        try:
            from services.geolocation import calcular_distancia_km, calcular_costo_envio
            if user_location:
                admin_lat = -25.2637
                admin_lon = -57.5759
                distancia = calcular_distancia_km(
                    user_location['latitude'], user_location['longitude'],
                    admin_lat, admin_lon
                )
                order.delivery_fee = calcular_costo_envio(distancia)
                total += order.delivery_fee
                order.total_amount = total
        except:
            order.delivery_fee = 0
        
        # ✅ PASO 4: Agregar items y descontar stock
        for item_data in order_items_temp:
            order_item = OrderItem(
                order=order,
                product=item_data['product'],
                quantity=item_data['quantity'],
                price_at_purchase=item_data['price']
            )
            db.session.add(order_item)
            
            # Descontar stock
            item_data['product'].stock -= item_data['quantity']
        
        # ✅ PASO 5: Guardar todo en la base de datos
        db.session.add(order)
        db.session.commit()
        
        # Limpiar carrito
        session.pop('cart', None)
        session.pop('user_location', None)
        
        # Notificar por SocketIO
        try:
            from app import socketio
            socketio.emit('new_order', {
                'order_id': order.id,
                'customer': current_user.email,
                'total': total,
                'created_at': order.created_at.strftime('%Y-%m-%d %H:%M')
            }, room='admin')
        except Exception as e:
            print(f"SocketIO error: {e}")
        
        flash('🎉 ¡Pedido creado exitosamente en QuickGo!', 'success') # 👈 CAMBIADO
        return redirect(url_for('main.dashboard'))
    
    # Mostrar resumen del carrito (GET request)
    cart_items = []
    for product_id, quantity in cart.items():
        product = Product.query.get(int(product_id))
        if product:
            cart_items.append({
                'name': product.name,
                'quantity': quantity,
                'price': product.price,
                'subtotal': product.price * quantity
            })
    
    total = sum(item['subtotal'] for item in cart_items)
    return render_template('order_confirm.html', form=form, cart_items=cart_items, total=total)


@main_bp.route('/order/<int:order_id>/receive', methods=['POST'])
@login_required
def mark_order_received(order_id):
    if current_user.is_admin or current_user.is_delivery:
        return redirect(url_for('main.dashboard'))
    
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    if order.status == 'shipped':
        order.status = 'delivered'
        order.delivered_at = datetime.now(timezone.utc)
        db.session.commit()
        flash('✅ Pedido marcado como recibido. ¡Gracias por tu compra en QuickGo!', 'success') # 👈 CAMBIADO
    else:
        flash('⚠️ Este pedido aún no ha sido enviado.', 'warning')
    
    return redirect(url_for('main.dashboard'))


@main_bp.route('/account/settings', methods=['GET', 'POST'])
@login_required
def account_settings():
    if current_user.is_admin or current_user.is_delivery:
        return redirect(url_for('main.dashboard'))
    
    if request.method == 'POST':
        theme = request.form.get('theme', 'gold')
        current_user.theme_color = theme
        db.session.commit()
        flash('🎨 Tema actualizado.', 'success')
        return redirect(url_for('main.account_settings'))
    
    return render_template('account_settings.html')


@main_bp.route('/password/reset/request', methods=['GET', 'POST'])
def reset_password_request():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    
    form = PasswordResetRequestForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            OTPCode.query.filter_by(user_id=user.id, purpose='reset_password', used=False).delete()
            
            otp = OTPCode(
                user_id=user.id,
                code=OTPCode.generate_code(),
                purpose='reset_password'
            )
            db.session.add(otp)
            db.session.commit()
            
            if send_otp_email(user.email, otp.code, 'reset_password'):
                flash('✅ Hemos enviado un código de recuperación a tu email.', 'success')
                return redirect(url_for('main.verify_otp', user_id=user.id, purpose='reset_password'))
        
        flash('📧 Si el email existe en nuestro sistema, recibirás instrucciones.', 'info')
        return redirect(url_for('main.login'))
    
    return render_template('reset_request.html', form=form)


@main_bp.route('/password/reset/new', methods=['GET', 'POST'])
def reset_password_new():
    user_id = session.get('reset_user_id')
    
    if not user_id:
        flash('⚠️ Sesión expirada. Solicita un nuevo código.', 'warning')
        return redirect(url_for('main.reset_password_request'))
    
    user = User.query.get(user_id)
    if not user:
        session.pop('reset_user_id', None)
        return redirect(url_for('main.login'))
    
    form = PasswordResetForm()
    if form.validate_on_submit():
        user.set_password(form.password.data)
        db.session.commit()
        session.pop('reset_user_id', None)
        flash('✅ Contraseña actualizada. Ahora puedes iniciar sesión.', 'success')
        return redirect(url_for('main.login'))
    
    return render_template('reset_new.html', form=form, email=user.email)


# ============ ADMIN ROUTES (SOLO PARA ADMINISTRADOR) ============

@admin_bp.route('/')
@login_required
def dashboard():
    """✅ Dashboard del ADMINISTRADOR - Solo para admins"""
    
    # 🔴 Si es delivery, redirigir al panel de delivery
    if current_user.is_delivery:
        flash('ℹ️ Redirigiendo al panel de delivery.', 'info')
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si no es admin, redirigir al home
    if not current_user.is_admin:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    # ✅ Si es admin, mostrar el dashboard
    # Estadísticas generales
    total_users = User.query.count()
    total_sales = db.session.query(db.func.sum(Order.total_amount)).filter_by(status='delivered').scalar() or 0
    total_orders = Order.query.count()
    pending_orders = Order.query.filter_by(status='pending').count()
    
    from sqlalchemy import func
    
    # Producto más vendido
    best_seller_query = db.session.query(
        Product.name,
        func.sum(OrderItem.quantity).label('total_sold')
    ).join(OrderItem, Product.id == OrderItem.product_id)\
     .join(Order, OrderItem.order_id == Order.id)\
     .filter(Order.status == 'delivered')\
     .group_by(Product.id)\
     .order_by(func.sum(OrderItem.quantity).desc())\
     .first()
    
    best_seller = list(best_seller_query) if best_seller_query else None
    
    # Cliente más activo
    top_customer_query = db.session.query(
        User.email,
        func.count(Order.id).label('order_count')
    ).join(Order, User.id == Order.user_id)\
     .filter(Order.status == 'delivered')\
     .group_by(User.id)\
     .order_by(func.count(Order.id).desc())\
     .first()
    
    top_customer = list(top_customer_query) if top_customer_query else None
    
    # Pedidos recientes
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(10).all()
    
    # Productos con bajo stock
    low_stock_products = Product.query.filter(
        Product.is_active == True,
        Product.stock > 0,
        Product.stock < 10
    ).order_by(Product.stock.asc()).limit(5).all()
    
    # 📊 DATOS PARA GRÁFICOS - Convertir a listas simples
    
    # Ventas por categoría (últimos 30 días)
    thirty_days_ago = datetime.now(timezone.utc) - timedelta(days=30)
    
    sales_by_category_query = db.session.query(
        Category.name,
        func.sum(OrderItem.quantity * OrderItem.price_at_purchase).label('revenue')
    ).join(Product, Category.id == Product.category_id)\
     .join(OrderItem, Product.id == OrderItem.product_id)\
     .join(Order, OrderItem.order_id == Order.id)\
     .filter(Order.created_at >= thirty_days_ago, Order.status == 'delivered')\
     .group_by(Category.id)\
     .all()
    
    # ✅ Convertir a lista de listas simples
    sales_by_category = [[row[0], float(row[1])] for row in sales_by_category_query]
    
    # Pedidos por estado (para gráfico de dona)
    orders_by_status_query = db.session.query(
        Order.status,
        func.count(Order.id).label('count')
    ).group_by(Order.status).all()
    
    # ✅ Convertir a lista de listas simples
    orders_by_status = [[row[0], row[1]] for row in orders_by_status_query]
    
    # Ventas diarias (últimos 7 días - para gráfico de línea)
    seven_days_ago = datetime.now(timezone.utc) - timedelta(days=7)
    
    daily_sales_query = db.session.query(
        db.func.date(Order.created_at).label('date'),
        func.sum(Order.total_amount).label('total')
    ).filter(Order.created_at >= seven_days_ago, Order.status == 'delivered')\
     .group_by(db.func.date(Order.created_at))\
     .order_by(db.func.date(Order.created_at))\
     .all()
    
    # ✅ Convertir a lista de listas simples
    daily_sales = [[str(row[0]), float(row[1])] for row in daily_sales_query]
    
    # Stock por producto (para gráfico de barras)
    stock_products_query = Product.query.filter(
        Product.is_active == True,
        Product.stock > 0
    ).order_by(Product.stock.desc()).limit(10).all()
    
    # ✅ Convertir a lista de diccionarios
    stock_products = [{
        'id': p.id,
        'name': p.name,
        'stock': p.stock,
        'price': p.price,
        'category': p.category.name if p.category else 'Sin categoría'
    } for p in stock_products_query]
    
    # Obtener delivery users para el selector
    delivery_users = User.query.filter_by(is_delivery=True, is_active=True).all()
    
    return render_template('admin/dashboard.html',
        total_users=total_users,
        total_sales=total_sales,
        total_orders=total_orders,
        pending_orders=pending_orders,
        best_seller=best_seller,
        top_customer=top_customer,
        recent_orders=recent_orders,
        low_stock_products=low_stock_products,
        sales_by_category=sales_by_category,
        orders_by_status=orders_by_status,
        daily_sales=daily_sales,
        stock_products=stock_products,
        delivery_users=delivery_users
    )


@admin_bp.route('/users')
@login_required
def manage_users():
    # 🔴 Si es delivery, DENEGAR acceso
    if current_user.is_delivery:
        flash('❌ Los delivery no tienen acceso a esta sección.', 'danger')
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si no es admin, DENEGAR acceso
    if not current_user.is_admin:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin/users.html', users=users)


@admin_bp.route('/users/<int:user_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_user(user_id):
    # 🔴 Si es delivery, DENEGAR acceso
    if current_user.is_delivery:
        flash('❌ Los delivery no tienen acceso a esta sección.', 'danger')
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si no es admin, DENEGAR acceso
    if not current_user.is_admin:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    user = User.query.get_or_404(user_id)
    form = AdminUserForm(obj=user)
    
    if form.validate_on_submit():
        user.email = form.email.data
        user.phone = form.phone.data
        user.is_active = form.is_active.data
        user.is_admin = form.is_admin.data
        
        # ✅ Guardar is_delivery desde el checkbox del template
        user.is_delivery = request.form.get('is_delivery') == 'true'
        
        db.session.commit()
        flash('✅ Usuario actualizado.', 'success')
        return redirect(url_for('admin.manage_users'))
    
    return render_template('admin/user_form.html', form=form, user=user)


@admin_bp.route('/users/<int:user_id>/reset-password', methods=['POST'])
@login_required
def reset_user_password(user_id):
    # 🔴 Si es delivery, DENEGAR acceso
    if current_user.is_delivery:
        flash('❌ Los delivery no tienen acceso a esta sección.', 'danger')
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si no es admin, DENEGAR acceso
    if not current_user.is_admin:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    user = User.query.get_or_404(user_id)
    new_password = secrets.token_urlsafe(8)
    user.set_password(new_password)
    db.session.commit()
    
    flash(f'✅ Contraseña reseteada. Nueva contraseña temporal: {new_password}', 'success')
    return redirect(url_for('admin.manage_users'))


@admin_bp.route('/products')
@login_required
def manage_products():
    # 🔴 Si es delivery, DENEGAR acceso
    if current_user.is_delivery:
        flash('❌ Los delivery no tienen acceso a esta sección.', 'danger')
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si no es admin, DENEGAR acceso
    if not current_user.is_admin:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    products = Product.query.order_by(Product.created_at.desc()).all()
    categories = Category.query.all()
    return render_template('admin/products.html', products=products, categories=categories)


@admin_bp.route('/products/new', methods=['GET', 'POST'])
@login_required
def create_product():
    # 🔴 Si es delivery, DENEGAR acceso
    if current_user.is_delivery:
        flash('❌ Los delivery no tienen acceso a esta sección.', 'danger')
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si no es admin, DENEGAR acceso
    if not current_user.is_admin:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    form = ProductForm()
    categories = Category.query.all()
    form.populate_categories(categories)
    
    if form.validate_on_submit():
        product = Product(
            name=form.name.data,
            description=form.description.data,
            precio_compra=form.precio_compra.data,
            price=form.price.data,
            stock=form.stock.data,
            category_id=form.category_id.data
        )
        
        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename != '' and allowed_file(file.filename):
                filename = secure_filename(f"{secrets.token_hex(8)}_{file.filename}")
                filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], 'uploads', filename)
                file.save(filepath)
                product.image_url = f'uploads/{filename}'
        
        db.session.add(product)
        db.session.commit()
        flash('✅ Producto creado.', 'success')
        return redirect(url_for('admin.manage_products'))
    
    return render_template('admin/product_form.html', form=form, categories=categories)


@admin_bp.route('/products/<int:product_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_product(product_id):
    # 🔴 Si es delivery, DENEGAR acceso
    if current_user.is_delivery:
        flash('❌ Los delivery no tienen acceso a esta sección.', 'danger')
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si no es admin, DENEGAR acceso
    if not current_user.is_admin:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    product = Product.query.get_or_404(product_id)
    form = ProductForm(obj=product)
    categories = Category.query.all()
    form.populate_categories(categories)
    
    if form.validate_on_submit():
        product.name = form.name.data
        product.description = form.description.data
        product.precio_compra = form.precio_compra.data
        product.price = form.price.data
        product.stock = form.stock.data
        product.category_id = form.category_id.data
        
        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename != '' and allowed_file(file.filename):
                if product.image_url:
                    old_path = os.path.join(current_app.config['UPLOAD_FOLDER'], 
                                          os.path.basename(product.image_url))
                    if os.path.exists(old_path):
                        os.remove(old_path)
                
                filename = secure_filename(f"{secrets.token_hex(8)}_{file.filename}")
                filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], 'uploads', filename)
                file.save(filepath)
                product.image_url = f'uploads/{filename}'
        
        db.session.commit()
        flash('✅ Producto actualizado.', 'success')
        return redirect(url_for('admin.manage_products'))
    
    return render_template('admin/product_form.html', form=form, product=product, categories=categories)


@admin_bp.route('/products/<int:product_id>/delete', methods=['POST'])
@login_required
def delete_product(product_id):
    # 🔴 Si es delivery, DENEGAR acceso
    if current_user.is_delivery:
        flash('❌ Los delivery no tienen acceso a esta sección.', 'danger')
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si no es admin, DENEGAR acceso
    if not current_user.is_admin:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    product = Product.query.get_or_404(product_id)
    
    if product.image_url:
        img_path = os.path.join(current_app.config['UPLOAD_FOLDER'], 
                               os.path.basename(product.image_url))
        if os.path.exists(img_path):
            os.remove(img_path)
    
    db.session.delete(product)
    db.session.commit()
    flash('🗑️ Producto eliminado.', 'info')
    return redirect(url_for('admin.manage_products'))


@admin_bp.route('/categories', methods=['GET', 'POST'])
@login_required
def manage_categories():
    # 🔴 Si es delivery, DENEGAR acceso
    if current_user.is_delivery:
        flash('❌ Los delivery no tienen acceso a esta sección.', 'danger')
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si no es admin, DENEGAR acceso
    if not current_user.is_admin:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        name = request.form.get('name')
        if name:
            if not Category.query.filter_by(name=name).first():
                category = Category(name=name)
                db.session.add(category)
                db.session.commit()
                flash('✅ Categoría creada.', 'success')
            else:
                flash('⚠️ Esta categoría ya existe.', 'warning')
        return redirect(url_for('admin.manage_categories'))
    
    categories = Category.query.order_by(Category.name).all()
    return render_template('admin/categories.html', categories=categories)


@admin_bp.route('/categories/<int:category_id>/delete', methods=['POST'])
@login_required
def delete_category(category_id):
    # 🔴 Si es delivery, DENEGAR acceso
    if current_user.is_delivery:
        flash('❌ Los delivery no tienen acceso a esta sección.', 'danger')
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si no es admin, DENEGAR acceso
    if not current_user.is_admin:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    category = Category.query.get_or_404(category_id)
    
    # ✅ CAMBIO IMPORTANTE: len() en vez de .count()
    if len(category.products) > 0:
        flash('⚠️ No se puede eliminar: hay productos asociados.', 'warning')
    else:
        db.session.delete(category)
        db.session.commit()
        flash('🗑️ Categoría eliminada.', 'info')
    
    return redirect(url_for('admin.manage_categories'))


@admin_bp.route('/orders')
@login_required
def manage_orders():
    # 🔴 Si es delivery, DENEGAR acceso
    if current_user.is_delivery:
        flash('❌ Los delivery no tienen acceso a esta sección.', 'danger')
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si no es admin, DENEGAR acceso
    if not current_user.is_admin:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    status_filter = request.args.get('status', 'all')
    query = Order.query
    
    if status_filter != 'all':
        query = query.filter_by(status=status_filter)
    
    orders = query.order_by(Order.created_at.desc()).all()
    
    # ✅ Obtener delivery users para el selector
    delivery_users = User.query.filter_by(is_delivery=True, is_active=True).all()
    
    return render_template('admin/orders.html', 
                          orders=orders, 
                          current_status=status_filter, 
                          delivery_users=delivery_users)


@admin_bp.route('/orders/<int:order_id>/update-status', methods=['POST'])
@login_required
def update_order_status(order_id):
    # 🔴 Si es delivery, DENEGAR acceso
    if current_user.is_delivery:
        flash('❌ Los delivery no tienen acceso a esta sección.', 'danger')
        return redirect(url_for('delivery.dashboard'))
    
    # 🔴 Si no es admin, DENEGAR acceso
    if not current_user.is_admin:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    order = Order.query.get_or_404(order_id)
    new_status = request.form.get('status')
    delivery_driver_id = request.form.get('delivery_driver_id', type=int)  # ✅ Recibir delivery_id
    
    if new_status in ['pending', 'shipped', 'delivered', 'cancelled']:
        old_status = order.status
        order.status = new_status
        
        # ✅ Asignar delivery si se proporciona y el estado es "shipped"
        if delivery_driver_id and new_status == 'shipped':
            order.delivery_driver_id = delivery_driver_id
        
        if new_status == 'delivered':
            order.delivered_at = datetime.now(timezone.utc)
        
        db.session.commit()
        
        # Notificar al cliente y delivery
        try:
            from app import socketio
            
            # Notificar al cliente
            socketio.emit('order_status_update', {
                'order_id': order.id,
                'user_id': order.user_id,
                'old_status': old_status,
                'new_status': new_status
            }, room=f'user_{order.user_id}')
            
            # Notificar al delivery si fue asignado
            if order.delivery_driver_id and new_status == 'shipped':
                socketio.emit('new_delivery_assignment', {
                    'order_id': order.id,
                    'customer': order.customer.email,
                    'address': order.shipping_address
                }, room=f'delivery_{order.delivery_driver_id}')
        except:
            pass
        
        flash(f'✅ Estado actualizado: {order.status_label}', 'success')
    else:
        flash('❌ Estado inválido.', 'danger')
    
    return redirect(url_for('admin.manage_orders'))


@admin_bp.route('/api/orders/<int:order_id>/location')
@login_required
def get_order_location(order_id):
    # 🔴 Si es delivery, DENEGAR acceso
    if current_user.is_delivery:
        return jsonify({'error': 'Unauthorized'}), 403
    
    # 🔴 Si no es admin, DENEGAR acceso
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    order = Order.query.get_or_404(order_id)
    
    return jsonify({
        'order_id': order.id,
        'client': {
            'latitude': order.client_latitude,
            'longitude': order.client_longitude,
            'address': order.shipping_address
        },
        'delivery': {
            'latitude': order.delivery_latitude,
            'longitude': order.delivery_longitude
        } if order.delivery_latitude else None,
        'status': order.status,
        'delivery_fee': order.delivery_fee
    })


# ============ DELIVERY ROUTES (NUEVAS) ============

@delivery_bp.route('/dashboard')
@login_required
def dashboard():
    """Dashboard del Delivery Driver"""
    if not current_user.is_delivery:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    # Pedidos activos asignados al delivery
    delivery_orders = Order.query.filter_by(
        delivery_driver_id=current_user.id,
        status='shipped'
    ).order_by(Order.created_at.desc()).all()
    
    # Todos los pedidos del delivery (para historial)
    all_delivery_orders = Order.query.filter_by(
        delivery_driver_id=current_user.id
    ).filter(
        Order.status.in_(['delivered', 'cancelled'])
    ).order_by(Order.created_at.desc()).all()
    
    # Calcular ganancias
    today = datetime.now(timezone.utc).date()
    night_start = datetime.now(timezone.utc).replace(hour=18, minute=0, second=0, microsecond=0)
    
    today_earnings = 0
    today_deliveries = 0
    night_earnings = 0
    night_deliveries = 0
    total_deliveries = len([o for o in all_delivery_orders if o.status == 'delivered'])
    completed_orders = total_deliveries
    rejected_orders = len([o for o in all_delivery_orders if o.status == 'cancelled'])
    
    for order in all_delivery_orders:
        if order.status == 'delivered' and order.delivery_fee:
            # Ganancia de hoy
            if order.delivered_at and order.delivered_at.date() == today:
                today_earnings += order.delivery_fee
                today_deliveries += 1
            
            # Ganancia de la noche (después de las 18:00)
            if order.delivered_at and order.delivered_at >= night_start:
                night_earnings += order.delivery_fee
                night_deliveries += 1
    
    return render_template('delivery/dashboard.html', 
                          delivery_orders=delivery_orders,
                          all_delivery_orders=all_delivery_orders,
                          today_earnings=today_earnings,
                          today_deliveries=today_deliveries,
                          night_earnings=night_earnings,
                          night_deliveries=night_deliveries,
                          total_deliveries=total_deliveries,
                          completed_orders=completed_orders,
                          rejected_orders=rejected_orders)


@delivery_bp.route('/api/location/update', methods=['POST'])
@login_required
def update_location():
    """Delivery actualiza su ubicación"""
    if not current_user.is_delivery:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    
    if not data.get('latitude') or not data.get('longitude'):
        return jsonify({'error': 'Coordenadas requeridas'}), 400
    
    # Actualizar ubicación del usuario
    current_user.latitude = data['latitude']
    current_user.longitude = data['longitude']
    db.session.commit()
    
    # Notificar a clientes con pedidos activos
    active_orders = Order.query.filter_by(
        delivery_driver_id=current_user.id,
        status='shipped'
    ).all()
    
    try:
        from app import socketio
        for order in active_orders:
            socketio.emit('delivery_location_update', {
                'order_id': order.id,
                'latitude': data['latitude'],
                'longitude': data['longitude']
            }, room=f'user_{order.user_id}')
    except:
        pass
    
    return jsonify({'status': 'ok'})


@delivery_bp.route('/api/arrived/<int:order_id>', methods=['POST'])
@login_required
def mark_arrived(order_id):
    """Delivery marca que llegó"""
    if not current_user.is_delivery:
        return jsonify({'error': 'Unauthorized'}), 403
    
    order = Order.query.get_or_404(order_id)
    
    if order.delivery_driver_id != current_user.id:
        return jsonify({'error': 'No autorizado'}), 403
    
    order.driver_arrived = True
    db.session.commit()
    
    # Notificar al cliente
    try:
        from app import socketio
        socketio.emit('driver_arrived', {
            'order_id': order.id,
            'message': '¡Tu delivery llegó!'
        }, room=f'user_{order.user_id}')
    except:
        pass
    
    return jsonify({'success': True})


@delivery_bp.route('/order/<int:order_id>/mark-delivered', methods=['POST'])
@login_required
def mark_delivered(order_id):
    """Delivery marca pedido como entregado"""
    if not current_user.is_delivery:
        flash('❌ Acceso denegado.', 'danger')
        return redirect(url_for('main.index'))
    
    order = Order.query.get_or_404(order_id)
    
    if order.delivery_driver_id != current_user.id:
        flash('❌ No autorizado.', 'danger')
        return redirect(url_for('delivery.dashboard'))
    
    order.status = 'delivered'
    order.delivered_at = datetime.now(timezone.utc)
    db.session.commit()
    
    # Notificar
    try:
        from app import socketio
        socketio.emit('order_delivered', {
            'order_id': order.id
        }, room=f'user_{order.user_id}')
    except:
        pass
    
    flash('✅ Pedido marcado como entregado.', 'success')
    return redirect(url_for('delivery.dashboard'))


# ============ GEOLOCALIZACIÓN ROUTES (NUEVAS) ============

@main_bp.route('/api/location/update', methods=['POST'])
@login_required
def update_location():
    """Cliente actualiza su ubicación en tiempo real"""
    data = request.get_json()
    
    if not data.get('latitude') or not data.get('longitude'):
        return jsonify({'error': 'Coordenadas requeridas'}), 400
    
    # Guardar ubicación en sesión para usarla en el pedido
    session['user_location'] = {
        'latitude': data['latitude'],
        'longitude': data['longitude'],
        'updated_at': datetime.utcnow().isoformat()
    }
    
    # Notificar por SocketIO si hay un pedido activo
    if current_user.get_pending_order():
        try:
            from app import socketio
            socketio.emit('location_update', {
                'user_id': current_user.id,
                'latitude': data['latitude'],
                'longitude': data['longitude'],
                'order_id': current_user.get_pending_order().id
            }, room='admin')
        except:
            pass
    
    return jsonify({'status': 'ok'})


@main_bp.route('/api/location/calculate-delivery', methods=['POST'])
@login_required
def calculate_delivery_fee():
    """Calcula el costo de envío según la ubicación"""
    try:
        from services.geolocation import calcular_distancia_km, calcular_costo_envio
        
        data = request.get_json()
        client_lat = data.get('latitude')
        client_lon = data.get('longitude')
        
        # Punto de referencia del admin (Coordenadas de Asunción, Paraguay)
        admin_lat = -25.2637
        admin_lon = -57.5759
        
        distancia = calcular_distancia_km(client_lat, client_lon, admin_lat, admin_lon)
        costo = calcular_costo_envio(distancia)
        
        return jsonify({
            'distance_km': round(distancia, 2) if distancia else None,
            'delivery_fee': costo,
            'fee_formatted': f'GS {costo:,}'.replace(',', '.')
        })
    except Exception as e:
        print(f"Error calculando envío: {e}")
        return jsonify({
            'distance_km': None,
            'delivery_fee': 10000,
            'fee_formatted': 'GS 10.000'
        })


# ============ API ROUTES ============

@main_bp.route('/api/products/search')
def api_search_products():
    query = request.args.get('q', '')
    if len(query) < 2:
        return jsonify([])
    
    products = Product.query.filter(
        Product.is_active == True,
        Product.stock > 0,
        Product.name.ilike(f'%{query}%')
    ).limit(10).all()
    
    return jsonify([{
        'id': p.id,
        'name': p.name,
        'price': p.price,
        'image': p.image_url or '/static/images/placeholder.png'
    } for p in products])