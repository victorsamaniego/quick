from flask_wtf import FlaskForm
from flask_wtf.file import FileAllowed, FileRequired
from wtforms import StringField, PasswordField, EmailField, TelField, TextAreaField, FloatField, IntegerField, SelectField, DecimalField, FileField, SubmitField, BooleanField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError, Optional, NumberRange
from models import User


class RegistrationForm(FlaskForm):
    email = EmailField('Email', validators=[DataRequired(), Email()])
    phone = TelField('Teléfono', validators=[DataRequired(), Length(min=8, max=20)])
    password = PasswordField('Contraseña', validators=[
        DataRequired(), 
        Length(min=8, message='La contraseña debe tener al menos 8 caracteres')
    ])
    confirm_password = PasswordField('Confirmar Contraseña', validators=[
        DataRequired(), 
        EqualTo('password', message='Las contraseñas no coinciden')
    ])
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Este email ya está registrado.')


class LoginForm(FlaskForm):
    email = EmailField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Contraseña', validators=[DataRequired()])


class OTPVerificationForm(FlaskForm):
    code = StringField('Código de verificación', validators=[
        DataRequired(), 
        Length(min=6, max=6, message='El código debe tener 6 dígitos')
    ])


class PasswordResetRequestForm(FlaskForm):
    email = EmailField('Email', validators=[DataRequired(), Email()])


class PasswordResetForm(FlaskForm):
    password = PasswordField('Nueva Contraseña', validators=[
        DataRequired(), 
        Length(min=8, message='La contraseña debe tener al menos 8 caracteres')
    ])
    confirm_password = PasswordField('Confirmar Nueva Contraseña', validators=[
        DataRequired(), 
        EqualTo('password', message='Las contraseñas no coinciden')
    ])


class ProductForm(FlaskForm):
    name = StringField('Nombre del Producto', validators=[DataRequired(), Length(max=200)])
    description = TextAreaField('Descripción', validators=[Optional()])
    precio_compra = DecimalField('Precio de Compra (Gs)', validators=[DataRequired(), NumberRange(min=0)])
    price = DecimalField('Precio de Venta (Gs)', validators=[DataRequired(), NumberRange(min=0)])
    stock = IntegerField('Stock', validators=[DataRequired(), NumberRange(min=0)])
    category_id = SelectField('Categoría', coerce=int, validators=[DataRequired()])
    image = FileField('Imagen del Producto', validators=[FileAllowed(['jpg', 'png', 'jpeg'], 'Solo imágenes!')])
    submit = SubmitField('Guardar Producto')
    
    def populate_categories(self, categories):
        self.category_id.choices = [(cat.id, cat.name) for cat in categories]


class OrderForm(FlaskForm):
    shipping_address = TextAreaField('Dirección de envío', validators=[DataRequired()])
    shipping_phone = TelField('Teléfono de contacto', validators=[DataRequired(), Length(min=8, max=20)])
    shipping_reference = StringField('Referencia (opcional)', validators=[Optional()])


class AdminUserForm(FlaskForm):
    email = EmailField('Email', validators=[DataRequired(), Email()])
    phone = TelField('Teléfono', validators=[DataRequired()])
    is_active = SelectField('Estado', coerce=bool, choices=[(True, 'Activo'), (False, 'Inactivo')])
    is_admin = SelectField('Rol Admin', coerce=bool, choices=[(True, 'Sí'), (False, 'No')])
    # ✅ is_delivery NO va aquí porque es un checkbox separado en el template


class CategoryForm(FlaskForm):
    name = StringField('Nombre de categoría', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Descripción', validators=[Optional()])