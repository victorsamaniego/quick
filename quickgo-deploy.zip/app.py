from flask import Flask, session, render_template, request
from flask_mail import Mail
from flask_socketio import SocketIO, emit, join_room, leave_room
from flask_login import LoginManager, current_user
from config import Config
from models import db, User
from routes import main_bp, admin_bp, delivery_bp  # ✅ Agregar delivery_bp
import os
from datetime import datetime, timezone

# Inicializar extensiones
mail = Mail()
socketio = SocketIO(cors_allowed_origins="*", async_mode='threading')
login_manager = LoginManager()

def create_app(config_class=Config):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_class)
    
    # Crear carpetas necesarias
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], 'uploads'), exist_ok=True)
    
    # Inicializar extensiones
    db.init_app(app)
    mail.init_app(app)
    socketio.init_app(app)
    login_manager.init_app(app)
    
    # Flask-Login: cargar usuario
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
    
    # Registrar blueprints
    app.register_blueprint(main_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(delivery_bp)  # ✅ Agregar esta línea
    
    # Context processor para variables globales en templates
    @app.context_processor
    def inject_globals():
        return {
            'now': datetime.now(timezone.utc),
            'current_year': datetime.now(timezone.utc).year,
            'current_user': current_user
        }
    
    # Error handlers
    @app.errorhandler(404)
    def not_found_error(error):
        return render_template('error.html', error_code=404, message='Página no encontrada'), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template('error.html', error_code=500, message='Error interno del servidor'), 500
    
    # ========== SOCKETIO EVENTS ==========
    
    @socketio.on('connect')
    def handle_connect():
        print(f'🔌 Cliente conectado: {request.sid}')
    
    @socketio.on('disconnect')
    def handle_disconnect():
        print(f'❌ Cliente desconectado: {request.sid}')
    
    @socketio.on('join_admin_room')
    def handle_join_admin(data):
        """Admin se une a la sala de notificaciones"""
        if current_user.is_authenticated and current_user.is_admin:
            join_room('admin')
            print(f'👑 Admin {current_user.email} se unió a admin room')
            emit('admin_connected', {'status': 'connected'}, room=request.sid)
    
    @socketio.on('join_user_room')
    def handle_join_user(data):
        """Usuario se une a su sala personal"""
        if current_user.is_authenticated:
            user_id = data.get('user_id')
            if user_id == current_user.id:
                join_room(f'user_{user_id}')
                print(f'👤 Usuario {current_user.email} se unió a user_{user_id}')
                emit('user_connected', {'status': 'connected'}, room=request.sid)
    
    @socketio.on('join_delivery_room')
    def handle_join_delivery(data):
        """Delivery se une a su sala personal"""
        if current_user.is_authenticated and current_user.is_delivery:
            user_id = data.get('user_id')
            if user_id == current_user.id:
                join_room(f'delivery_{user_id}')
                print(f'🛵 Delivery {current_user.email} se unió a delivery_{user_id}')
                emit('delivery_connected', {'status': 'connected'}, room=request.sid)
    
    @socketio.on('request_order_update')
    def handle_order_update(data):
        """Cliente solicita actualización de su pedido"""
        if current_user.is_authenticated:
            order_id = data.get('order_id')
            order = Order.query.get(order_id)
            if order and order.user_id == current_user.id:
                emit('order_status_update', {
                    'order_id': order.id,
                    'status': order.status,
                    'status_label': order.status_label,
                    'status_color': order.status_color
                }, room=request.sid)
    
    # ========== SOCKETIO EVENTS - GEOLOCALIZACIÓN ==========
    
    @socketio.on('user_location_update')
    def handle_user_location(data):
        """Cliente envía su ubicación en tiempo real"""
        user_id = data.get('user_id')
        latitude = data.get('latitude')
        longitude = data.get('longitude')
        
        if user_id and latitude and longitude:
            # Broadcast a admins que están viendo este pedido
            emit('client_location_update', {
                'user_id': user_id,
                'latitude': latitude,
                'longitude': longitude,
                'timestamp': datetime.now(timezone.utc).isoformat()
            }, room='admin')
    
    @socketio.on('delivery_location_update')
    def handle_delivery_location(data):
        """Delivery actualiza su ubicación"""
        order_id = data.get('order_id')
        latitude = data.get('latitude')
        longitude = data.get('longitude')
        
        if order_id and latitude and longitude:
            # Actualizar en base de datos (opcional)
            # Broadcast al cliente y admin
            emit('delivery_location_update', {
                'order_id': order_id,
                'latitude': latitude,
                'longitude': longitude,
                'timestamp': datetime.now(timezone.utc).isoformat()
            }, room=f'order_{order_id}')
    
    @socketio.on('join_order_room')
    def handle_join_order_room(data):
        """Unirse a la sala de un pedido específico para tracking"""
        if current_user.is_authenticated:
            order_id = data.get('order_id')
            if order_id:
                join_room(f'order_{order_id}')
                print(f'📦 Usuario {current_user.email} se unió a order_{order_id}')
    
    return app

# Importar Order aquí para evitar circular import
from models import Order

# Instancia de la app para gunicorn
app = create_app()

if __name__ == '__main__':
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)