from app import app, db
from models import User, Product, Category, Order, OrderItem, OTPCode

with app.app_context():
    # Crear todas las tablas según los modelos
    db.create_all()
    print("✅ Tablas de la base de datos verificadas/creadas exitosamente.")
    
    # Verificar si existe el admin principal
    admin_email = 'admin@podsluxury.com'
    admin_user = User.query.filter_by(email=admin_email).first()
    
    if not admin_user:
        # Crear admin si no existe
        admin = User(
            email=admin_email,
            phone='0981234567',
            is_admin=True,
            is_active=True,
            is_delivery=False
        )
        admin.set_password('4959761.sama')  # Tu contraseña habitual
        db.session.add(admin)
        db.session.commit()
        print(f"👑 Usuario admin creado:")
        print(f"   Email: {admin_email}")
        print(f"   Password: 4959761.sama")
    else:
        print(f"ℹ️ El usuario admin ({admin_email}) ya existe.")
        
    # Contar registros
    users_count = User.query.count()
    products_count = Product.query.count()
    print(f"\n📊 Resumen de la base de datos:")
    print(f"   Usuarios: {users_count}")
    print(f"   Productos: {products_count}")