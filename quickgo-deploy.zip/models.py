from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import random
import string

db = SQLAlchemy()


class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    is_admin = db.Column(db.Boolean, default=False)
    is_delivery = db.Column(db.Boolean, default=False)  # ✅ NUEVO: Usuario delivery
    theme_color = db.Column(db.String(20), default='gold')
    
    # ✅ CAMPOS DE GEOLOCALIZACIÓN
    latitude = db.Column(db.Float)      # Latitud del usuario
    longitude = db.Column(db.Float)     # Longitud del usuario
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relaciones
    orders = db.relationship('Order', backref='customer', lazy=True, foreign_keys='Order.user_id')
    delivery_orders = db.relationship('Order', backref='driver', lazy=True, foreign_keys='Order.delivery_driver_id')
    otp_codes = db.relationship('OTPCode', backref='user', lazy=True, cascade='all, delete-orphan')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_pending_order(self):
        """Obtiene el pedido pendiente del usuario (si existe)"""
        return Order.query.filter_by(user_id=self.id, status='pending').first()
    
    @property
    def is_customer(self):
        """Verifica si es cliente normal"""
        return not self.is_admin and not self.is_delivery
    
    def __repr__(self):
        return f'<User {self.email}>'


class OTPCode(db.Model):
    __tablename__ = 'otp_codes'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    code = db.Column(db.String(6), nullable=False)
    purpose = db.Column(db.String(20), nullable=False)  # 'register', 'reset_password'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    used = db.Column(db.Boolean, default=False)
    
    @staticmethod
    def generate_code():
        return ''.join(random.choices(string.digits, k=6))
    
    def is_expired(self, expiry_minutes=10):
        from datetime import timedelta
        return datetime.utcnow() > self.created_at + timedelta(minutes=expiry_minutes)
    
    def __repr__(self):
        return f'<OTPCode {self.code} for user {self.user_id}>'


class Category(db.Model):
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relaciones
    products = db.relationship('Product', backref='category', lazy=True)
    
    def __repr__(self):
        return f'<Category {self.name}>'


class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    precio_compra = db.Column(db.Float, nullable=False, default=0)  # ✅ Precio de compra
    price = db.Column(db.Float, nullable=False)  # Precio de venta
    stock = db.Column(db.Integer, default=0)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'))
    image_url = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # ✅ PROPIEDADES DE GANANCIAS
    
    @property
    def ganancia_unitaria(self):
        """Ganancia por unidad vendida"""
        return self.price - self.precio_compra
    
    @property
    def margen_ganancia(self):
        """Margen de ganancia en porcentaje"""
        if self.precio_compra > 0:
            return ((self.price - self.precio_compra) / self.precio_compra) * 100
        return 0
    
    @property
    def valor_inventario(self):
        """Valor total del inventario (basado en precio de compra)"""
        return self.precio_compra * self.stock
    
    @property
    def ganancia_potencial(self):
        """Ganancia potencial si se vende todo el stock"""
        return self.ganancia_unitaria * self.stock
    
    @property
    def valor_venta_total(self):
        """Valor total si se vende todo el stock (precio de venta)"""
        return self.price * self.stock
    
    # ✅ PROPIEDADES DE STOCK
    
    @property
    def is_low_stock(self):
        """Alerta de bajo stock (menos de 10 unidades)"""
        return self.stock < 10
    
    @property
    def is_available(self):
        """Producto disponible para compra"""
        return self.is_active and self.stock > 0
    
    @property
    def stock_status(self):
        """Estado del stock para mostrar con colores"""
        if self.stock == 0:
            return 'sin_stock'
        elif self.stock < 10:
            return 'bajo'
        elif self.stock < 30:
            return 'medio'
        else:
            return 'completo'
    
    @property
    def stock_status_color(self):
        """Color Bootstrap según el estado del stock"""
        colors = {
            'sin_stock': 'secondary',
            'bajo': 'danger',
            'medio': 'warning',
            'completo': 'success'
        }
        return colors.get(self.stock_status, 'secondary')
    
    def __repr__(self):
        return f'<Product {self.name}>'


class OrderItem(db.Model):
    __tablename__ = 'order_items'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    price_at_purchase = db.Column(db.Float, nullable=False)
    
    # Relaciones
    order = db.relationship('Order', backref='order_items_list')
    product = db.relationship('Product')
    
    @property
    def subtotal(self):
        return self.quantity * self.price_at_purchase


class Order(db.Model):
    __tablename__ = 'orders'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    delivery_driver_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)  # ✅ NUEVO: Driver asignado
    status = db.Column(db.String(20), default='pending')  # pending, shipped, delivered, cancelled
    total_amount = db.Column(db.Float, nullable=False)
    shipping_address = db.Column(db.String(500), nullable=False)
    shipping_phone = db.Column(db.String(20), nullable=False)
    shipping_reference = db.Column(db.String(200))
    
    # ✅ GEOLOCALIZACIÓN
    client_latitude = db.Column(db.Float)
    client_longitude = db.Column(db.Float)
    delivery_latitude = db.Column(db.Float)
    delivery_longitude = db.Column(db.Float)
    delivery_fee = db.Column(db.Float, default=0)
    
    # ✅ ESTADO DEL DELIVERY
    driver_arrived = db.Column(db.Boolean, default=False)  # ✅ Si el driver llegó
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    delivered_at = db.Column(db.DateTime)
    
    @property
    def items_list(self):
        """Retorna lista de items con datos del producto para el template"""
        return [{
            'product_name': item.product.name if item.product else 'Producto eliminado',
            'quantity': item.quantity,
            'price': item.price_at_purchase,
            'subtotal': item.subtotal
        } for item in self.order_items_list]
    
    @property
    def status_label(self):
        """Etiqueta legible del estado del pedido"""
        labels = {
            'pending': '⏳ Pendiente',
            'shipped': '🚚 Enviado',
            'delivered': '✅ Entregado',
            'cancelled': '❌ Cancelado'
        }
        return labels.get(self.status, self.status)
    
    @property
    def status_color(self):
        """Color de Bootstrap para el badge del estado"""
        colors = {
            'pending': 'warning',
            'shipped': 'info',
            'delivered': 'success',
            'cancelled': 'danger'
        }
        return colors.get(self.status, 'secondary')
    
    @property
    def driver_arrived_label(self):
        """Etiqueta del estado de llegada del delivery"""
        if self.driver_arrived:
            return '🎉 ¡Delivery llegó!'
        elif self.status == 'shipped':
            return '🛵 En camino'
        else:
            return '⏳ Pendiente'
    
    @property
    def ganancia_obtenida(self):
        """Calcula la ganancia obtenida de este pedido"""
        ganancia = 0
        for item in self.order_items_list:
            if item.product:
                ganancia += (item.product.price - item.product.precio_compra) * item.quantity
        return ganancia
    
    @property
    def distance_to_client(self):
        """Calcula distancia entre delivery y cliente (km)"""
        if self.delivery_latitude and self.client_latitude:
            try:
                from services.geolocation import calcular_distancia_km
                return calcular_distancia_km(
                    self.delivery_latitude, self.delivery_longitude,
                    self.client_latitude, self.client_longitude
                )
            except:
                return None
        return None
    
    def __repr__(self):
        return f'<Order #{self.id} - {self.status}>'